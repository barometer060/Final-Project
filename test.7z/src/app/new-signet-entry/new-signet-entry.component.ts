import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute,Route } from '@angular/router';

@Component({
  selector: 'app-new-signet-entry',
  templateUrl: './new-signet-entry.component.html',
  styleUrls: ['./new-signet-entry.component.css']
})
export class NewSignetEntryComponent implements OnInit {

  constructor(private roter:Router) { }

  ngOnInit() {
  // this.route.snapshot
  }
isNewEntry:boolean=false;
isExistingEntry:boolean=false;

  contentload(){
this.isNewEntry=true;
this.isExistingEntry=false;

  }
loadExisting(){
this.isExistingEntry=true;
this.isNewEntry=false;



}

}
