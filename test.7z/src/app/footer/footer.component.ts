import { Component, OnInit, HostListener } from "@angular/core";

@Component({
  selector: "app-footer",
  templateUrl: "./footer.component.html",
  styleUrls: ["./footer.component.css"]
})
export class FooterComponent implements OnInit {
  logo: string;

  @HostListener("scroll", ["$event"])
  onScroll(event: any) {
    // visible height + pixel scrolled >= total height
    if (
      event.target.offsetHeight + event.target.scrollTop >=
      event.target.scrollHeight
    ) {
      navbar.classList.add("sticky");
    } else navbar.classList.remove("sticky");
  }

  @HostListener("window:scroll", ["$event"])
  onScrollEvent($event) {
    var navbar = document.getElementById("footer");
    var sticky = navbar.offsetTop + 200;
    if (window.pageYOffset >= sticky) {
      navbar.classList.add("sticky");
    } else {
      navbar.classList.remove("sticky");
    }
  }
  constructor() {
    this.logo = "../../assets/images/wtw-logo.png";
  }
  ngOnInit() {}
}
