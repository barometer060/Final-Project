import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchComponent } from '../app/search/search.component';
import { NameChangeComponent } from '../app/amendments/name-change/name-change.component';
import { NewSignetEntryComponent } from '../app/new-signet-entry/new-signet-entry.component';
import { NewApprovalComponent } from '../app/amendments/new-approval/new-approval.component';
import { NoLongerApprovedComponent } from '../app/amendments/no-longer-approved/no-longer-approved.component';
// import { NewReinstatementApprovalComponent } from '../app/amendments/new-reinstatement-approval/new-reinstatement-approval.component'
import { UpdateToUnderlyingSecurityComponent } from '../app/amendments/update-to-underlying-security/update-to-underlying-security.component';
import { ApprovalStatusChangeComponent } from '../app/amendments/approval-status-change/approval-status-change.component'
import { NewSignetEntryFormComponent } from '../app/new-signet-entry-form/new-signet-entry-form.component'
import { AnalystComponent } from '../app/analyst/analyst.component';
import { SpoeComponent } from '../app/spoe/spoe.component'

import { OpsComponent } from '../app/ops/ops.component';

import {ReviewerComponent} from '../app/reviewer/reviewer.component';
import {HistoricalDataComponent} from '../app/historical-data/historical-data.component'


const routes: Routes = [
    { path: '', redirectTo: 'search', pathMatch: 'full' },
    { path: 'search', component: SearchComponent },
    // { path: 'newsignetentryform', component: NewSignetEntryFormComponent },
    { path: 'analyst', component: AnalystComponent },
    { path: 'ops', component: OpsComponent },
    { path: 'reviewer', component: ReviewerComponent },
    { path: 'spoe', component: SpoeComponent },
    { path: 'histdata', component: HistoricalDataComponent },

    {
        path: 'newrequest', component: NewSignetEntryComponent,
        children: [
            { path: '', component: NameChangeComponent },
            { path: 'namechange', component: NameChangeComponent },
            { path: 'namechange/:id', component: NameChangeComponent },
            { path: "newapproval", component: NewApprovalComponent },
            { path: "nolonger", component: NoLongerApprovedComponent },
            // { path: "newReinstatement", component: NewReinstatementApprovalComponent },
            { path: "updateSecurity", component: UpdateToUnderlyingSecurityComponent },
            { path: "approvalStatusChange", component: ApprovalStatusChangeComponent }
        ]
    },


];

export const AppRouting: ModuleWithProviders = RouterModule.forRoot(routes);