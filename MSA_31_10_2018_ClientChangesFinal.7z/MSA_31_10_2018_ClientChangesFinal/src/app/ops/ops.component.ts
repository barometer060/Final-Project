import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-ops',
  templateUrl: './ops.component.html',
  styleUrls: ['./ops.component.css']
})
export class OpsComponent implements OnInit {
public id=1;
  constructor(private router :Router,private activatedRoute:ActivatedRoute) { }

  ngOnInit() {
  }


   redirectToEdit(){
  this.router.navigate(['newrequest',{id:1}]);

  }

  redirectToNew(){
     this.router.navigate(['newrequest',{id:1}]);
}
}
