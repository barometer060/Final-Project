import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-reinstatement-approval',
  templateUrl: './new-reinstatement-approval.component.html',
  styleUrls: ['./new-reinstatement-approval.component.css']
})
export class NewReinstatementApprovalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
