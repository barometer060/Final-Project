import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NoLongerApprovedComponent } from './no-longer-approved.component';

describe('NoLongerApprovedComponent', () => {
  let component: NoLongerApprovedComponent;
  let fixture: ComponentFixture<NoLongerApprovedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NoLongerApprovedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NoLongerApprovedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
