import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewSignetEntryFormComponent } from './new-signet-entry-form.component';

describe('NewSignetEntryFormComponent', () => {
  let component: NewSignetEntryFormComponent;
  let fixture: ComponentFixture<NewSignetEntryFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewSignetEntryFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewSignetEntryFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
