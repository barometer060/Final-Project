import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-historical-data',
  templateUrl: './historical-data.component.html',
  styleUrls: ['./historical-data.component.css']
})
export class HistoricalDataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
