import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SpoeComponent } from './spoe.component';

describe('SpoeComponent', () => {
  let component: SpoeComponent;
  let fixture: ComponentFixture<SpoeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SpoeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SpoeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
