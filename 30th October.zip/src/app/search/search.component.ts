import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
declare var $: any;
@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
public id=1;
  constructor(private router :Router,private activatedRoute:ActivatedRoute) { }

  ngOnInit() {
  }

  redirectToEdit(){
  this.router.navigate(['newsignetentry',{id:1}]);

  }

  redirectToNew(){
     this.router.navigate(['newsignetentry',{id:1}]);
}
}
