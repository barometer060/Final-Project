import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-signet-entry-form',
  templateUrl: './new-signet-entry-form.component.html',
  styleUrls: ['./new-signet-entry-form.component.css']
})
export class NewSignetEntryFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
