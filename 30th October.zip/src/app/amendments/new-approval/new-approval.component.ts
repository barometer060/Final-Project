import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-approval',
  templateUrl: './new-approval.component.html',
  styleUrls: ['./new-approval.component.css']
})
export class NewApprovalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
