import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewReinstatementApprovalComponent } from './new-reinstatement-approval.component';

describe('NewReinstatementApprovalComponent', () => {
  let component: NewReinstatementApprovalComponent;
  let fixture: ComponentFixture<NewReinstatementApprovalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewReinstatementApprovalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewReinstatementApprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
