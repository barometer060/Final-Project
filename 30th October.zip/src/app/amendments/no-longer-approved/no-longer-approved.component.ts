import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-no-longer-approved',
  templateUrl: './no-longer-approved.component.html',
  styleUrls: ['./no-longer-approved.component.css']
})
export class NoLongerApprovedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
