import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-to-underlying-security',
  templateUrl: './update-to-underlying-security.component.html',
  styleUrls: ['./update-to-underlying-security.component.css']
})
export class UpdateToUnderlyingSecurityComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
