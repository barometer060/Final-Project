import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewSignetEntryComponent } from './new-signet-entry.component';

describe('NewSignetEntryComponent', () => {
  let component: NewSignetEntryComponent;
  let fixture: ComponentFixture<NewSignetEntryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewSignetEntryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewSignetEntryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
