import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';


import { AppComponent } from './app.component';
import { SearchComponent } from './search/search.component';
import { NameChangeComponent } from './amendments/name-change/name-change.component';
import { NewSignetEntryComponent } from './new-signet-entry/new-signet-entry.component';
import { AppRouting } from './app.routing';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { NavbarComponent } from './navbar/navbar.component';
import { DatepickerComponent } from './shared/datepicker/datepicker.component';
import { NewSignetEntryFormComponent } from './new-signet-entry-form/new-signet-entry-form.component';
import { NewApprovalComponent } from './amendments/new-approval/new-approval.component';
import { NoLongerApprovedComponent } from './amendments/no-longer-approved/no-longer-approved.component';
import { ApprovalStatusChangeComponent } from './amendments/approval-status-change/approval-status-change.component';
import { UpdateToUnderlyingSecurityComponent } from './amendments/update-to-underlying-security/update-to-underlying-security.component';
import { NewReinstatementApprovalComponent } from './amendments/new-reinstatement-approval/new-reinstatement-approval.component';
import { EditRequestComponent } from './edit-request/edit-request.component';
import { TabComponent } from './tab/tab.component';


@NgModule({
  declarations: [
    AppComponent,
    SearchComponent,
    NameChangeComponent,
    NewSignetEntryComponent,
    HeaderComponent,
    FooterComponent,
    NavbarComponent,
   DatepickerComponent,
   NewSignetEntryFormComponent,
   NewApprovalComponent,
   NoLongerApprovedComponent,
   ApprovalStatusChangeComponent,
   UpdateToUnderlyingSecurityComponent,
   NewReinstatementApprovalComponent,
   EditRequestComponent,
   TabComponent,
  ],
  imports: [
    BrowserModule,
    AppRouting,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
