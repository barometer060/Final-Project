import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consultancy-services',
  templateUrl: './consultancy-services.component.html',
  styleUrls: ['./consultancy-services.component.css']
})
export class ConsultancyServicesComponent implements OnInit {

  sourceCountries: string[] = ['Russia', 'Iraq', 'Egypt', 'Afghanistan', 'Ukraine'];
  currencies: string[] = ['GBP', 'HKD'];
  constructor() { }

  ngOnInit() {
  }

}
