import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-controlled-goods',
  templateUrl: './controlled-goods.component.html',
  styleUrls: ['./controlled-goods.component.css']
})
export class ControlledGoodsComponent implements OnInit {

  policyType: string;
  sourceCountries: string[] = ['Russia', 'Iraq', 'Egypt', 'Afghanistan', 'Ukraine'];

  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.policyType = "New Policy";
  }

  showInfo() {
    (<any>$('[data-toggle="popover"]')).popover({
      trigger: 'focus'
    });
  }

}
