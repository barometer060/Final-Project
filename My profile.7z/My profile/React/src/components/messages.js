import React, { Component } from 'react';
import '../App.css';

class Mesaages extends Component {
  render() {
    return (
      <div>
          display messages here
      </div>
    );
  }
}

export default Mesaages;

