import React, { Component } from 'react';
import '../App.css';

class mySubs extends Component {
  render() {
    return (
      <div>
        display my subscriptions here!!
      </div>
    );
  }
}

export default mySubs;
