import React, { Component } from 'react';
import './App.css';
import UserProfile from './components/userprofile';

class App extends Component {
  render() {
    return (
      <div>
        <UserProfile/>
        
      </div>
    );
  }
}

export default App;
