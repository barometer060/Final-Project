import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-approval-status-change',
  templateUrl: './approval-status-change.component.html',
  styleUrls: ['./approval-status-change.component.css']
})
export class ApprovalStatusChangeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
