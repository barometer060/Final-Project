import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NewSignetEntryFormComponent } from '../app/modules/new-signet-entry-form/new-signet-entry-form.component';
import { NewSignetEntryComponent } from '../app/modules/new-signet-entry/new-signet-entry.component';
import { NewApprovalComponent } from '../app/modules/amendments/new-approval/new-approval.component';
import { NoLongerApprovedComponent } from '../app/modules/amendments/no-longer-approved/no-longer-approved.component';
import { ApprovalStatusChangeComponent } from '../app/modules/amendments/approval-status-change/approval-status-change.component';
import { UpdateToUnderlyingSecComponent } from '../app/modules/amendments/update-to-underlying-sec/update-to-underlying-sec.component';
import { EditRequestComponent } from '../app/modules/edit-request/edit-request.component';
import { TabsComponent } from '../app/modules/tabs/tabs.component';
import { AnalystComponent } from '../app/modules/roles/analyst/analyst.component';
import { SignetUpdatedByComponent } from '../app/modules/roles/signet-updated-by/signet-updated-by.component';
import { ReviewerComponent } from '../app/modules/roles/reviewer/reviewer.component';
import { SpoeComponent } from '../app/modules/roles/spoe/spoe.component';
import { HistoricalDataComponent } from '../app/modules/historical-data/historical-data.component';
import { SearchComponent } from '../app/modules/search/search.component';
import { NameChangeComponent } from '../app/modules/amendments/name-change/name-change.component';



const routes: Routes = [
    { path: '', redirectTo: 'search', pathMatch: 'full' },
    { path: 'search', component: SearchComponent },
    // { path: 'newsignetentryform', component: NewSignetEntryFormComponent },
    { path: 'analyst', component: AnalystComponent },
    { path: 'signetupdatedby', component: SignetUpdatedByComponent },
    { path: 'reviewer', component: ReviewerComponent },
    { path: 'spoe', component: SpoeComponent },
    { path: 'histdata', component:HistoricalDataComponent },

    {
        path: 'newrequest', component: NewSignetEntryComponent,
        children: [
           { path: 'newsignetentryform', component: NewSignetEntryFormComponent },
            { path: '', component: NameChangeComponent },
            { path: 'namechange', component: NameChangeComponent },
            { path: 'namechange/:id', component: NameChangeComponent },
            { path: "newapproval", component: NewApprovalComponent },
            { path: "nolonger", component: NoLongerApprovedComponent },
            { path: "updateSecurity", component: UpdateToUnderlyingSecComponent },
            { path: "approvalStatusChange", component: ApprovalStatusChangeComponent }
        ]
    },


];

export const AppRouting: ModuleWithProviders = RouterModule.forRoot(routes);