import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-spoe',
  templateUrl: './spoe.component.html',
  styleUrls: ['./spoe.component.css']
})
export class SpoeComponent implements OnInit {

  queue=['val1']
  public id=1;
    constructor(private router :Router,private activatedRoute:ActivatedRoute) { }
  
    ngOnInit() {
    }
  
  
     redirectToEdit(){
    this.router.navigate(['newrequest',{id:1}]);
  
    }
  
    redirectToNew(){
       this.router.navigate(['newrequest',{id:1}]);
  }
}
