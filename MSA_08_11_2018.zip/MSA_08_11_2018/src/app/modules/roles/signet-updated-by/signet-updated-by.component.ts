import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-signet-updated-by',
  templateUrl: './signet-updated-by.component.html',
  styleUrls: ['./signet-updated-by.component.css']
})
export class SignetUpdatedByComponent implements OnInit {
  queue=['val1']
public id=1;
  constructor(private router :Router,private activatedRoute:ActivatedRoute) { }

  ngOnInit() {
  }


   redirectToEdit(){
  this.router.navigate(['newrequest',{id:1}]);

  }

  redirectToNew(){
     this.router.navigate(['newrequest',{id:1}]);
}
}
