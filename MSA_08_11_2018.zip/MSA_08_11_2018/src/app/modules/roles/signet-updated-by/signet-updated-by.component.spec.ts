import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SignetUpdatedByComponent } from './signet-updated-by.component';

describe('SignetUpdatedByComponent', () => {
  let component: SignetUpdatedByComponent;
  let fixture: ComponentFixture<SignetUpdatedByComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SignetUpdatedByComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SignetUpdatedByComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
