import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-signet-entry-form',
  templateUrl: './new-signet-entry-form.component.html',
  styleUrls: ['./new-signet-entry-form.component.css']
})
export class NewSignetEntryFormComponent implements OnInit {
public btnLabel="Save";
public newSignetObj={
  legalName:"",
  country:"",
  ownershipgrp:"",
  companyType:"",
  operatingCategory:"",
  sanctionTerritory:"",
  sanctionQualifier:"",
  approvalStatus:"",
  addBranchLink:"",
  street:"",
  city:"",
  state:"",
  postalCode:"",
  telephone:"",
  website:"",
  arcPrcMeeting:"",
  lorsCode:"",
  FEINAIIN:"",
  FATCAStatus:"",
  TOBAStatus:"",
  AMBestID:"",
  SPID:"",
  MoodysID:"",
  FitchID:"",
  requesterName:"",
  requesterBU:"",
  FETIndicator:"Yes",
  CAAFile:"Yes",

  
}
  constructor() { }

  ngOnInit() {
  }
  Saved(){
    console.log(this.newSignetObj);

this.btnLabel="Submit";


  }
}
