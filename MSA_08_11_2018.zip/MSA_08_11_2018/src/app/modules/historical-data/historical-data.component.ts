import { Component, OnInit } from '@angular/core';
import * as moment from 'moment/moment';

@Component({
  selector: 'app-historical-data',
  templateUrl: './historical-data.component.html',
  styleUrls: ['./historical-data.component.css']
})
export class HistoricalDataComponent implements OnInit {
endDate:string='';
startDate:string='';

queue=['val1'];
  constructor() { }

  ngOnInit() {
  }


  setEndDate(val){
this.endDate=val
}
setStartDate(val){
this.startDate=val

}
checkEndDateFormat(v){

}

checkValidation(val){
   var fromDate = moment(new Date(val), "dd-MMM-yyy");
   var currentDate=moment(new Date(this.startDate),"dd-MMM-yyy");
   return fromDate.isBefore(currentDate,'day');
  }

}
