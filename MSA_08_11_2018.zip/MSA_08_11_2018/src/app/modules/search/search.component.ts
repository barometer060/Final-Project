import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
declare var $: any;
import * as moment from 'moment/moment';


@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
public id=1;
endDate:string='';
startDate:string='';
queue=['val1'];
  constructor(private router :Router,private activatedRoute:ActivatedRoute) { }

  ngOnInit() {
  }

  redirectToEdit(){
  this.router.navigate(['newrequest',{id:1}]);

  }

  redirectToNew(){
     this.router.navigate(['newrequest',{id:1}]);
}

setEndDate(val){
this.endDate=val
}
setStartDate(val){
this.startDate=val

}
checkEndDateFormat(v){

}

checkValidation(val){
   var fromDate = moment(new Date(val), "dd-MMM-yyy");
   var currentDate=moment(new Date(this.startDate),"dd-MMM-yyy");
   return fromDate.isBefore(currentDate,'day');
  }
}
