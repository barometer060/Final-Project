import { Component, OnInit } from '@angular/core';
import * as moment from 'moment/moment';


@Component({
  selector: 'app-update-to-underlying-sec',
  templateUrl: './update-to-underlying-sec.component.html',
  styleUrls: ['./update-to-underlying-sec.component.css']
})
export class UpdateToUnderlyingSecComponent implements OnInit {

  updateUnder={
    approvalstatus: "Pending"
    }

    restrictions = ["Approved for US Healthcare business only",
    "Approved for US Related Business Only",
    "US Domestic Business only"];
qualifiers = ["Use Citizens Property Insurance Corporation Client Instruction Letter",
  "Use Risk Retention Group client instruction letter",
  "RPO Approval Required each and every risk"];

  endDate:string='';
startDate:string='';
  constructor() { }

  ngOnInit() {
  }

  setEndDate(val){
this.endDate=val
}
setStartDate(val){
this.startDate=val

}
checkEndDateFormat(v){

}

checkValidation(val){
   var fromDate = moment(new Date(val), "dd-MMM-yyy");
   var currentDate=moment(new Date(this.startDate),"dd-MMM-yyy");
   return fromDate.isBefore(currentDate,'day');
  }

}
