import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateToUnderlyingSecComponent } from './update-to-underlying-sec.component';

describe('UpdateToUnderlyingSecComponent', () => {
  let component: UpdateToUnderlyingSecComponent;
  let fixture: ComponentFixture<UpdateToUnderlyingSecComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateToUnderlyingSecComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateToUnderlyingSecComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
