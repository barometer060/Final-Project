import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-name-change',
  templateUrl: './name-change.component.html',
  styleUrls: ['./name-change.component.css']
})
export class NameChangeComponent implements OnInit {
  status=false;
  nameChange={
    legalname:"Mediterranean and Gulf Insurance and Reinsurance Group The (MEDGULF)",
    approvalstatus:"Not Approved",
    ownershipgroup:"Abacus Group",
    street:"Baker's Street",
    city:"London",
    state:"UK",
    postalcode:"400 698",
    telephone:"400698",
    website:"www.willistowerswatson.com"
  }
  
  
  restrictions = ["Approved for US Healthcare business only",
    "Approved for US Related Business Only",
    "US Domestic Business only"];
  qualifiers = ["Use Citizens Property Insurance Corporation Client Instruction Letter",
    "Use Risk Retention Group client instruction letter",
    "RPO Approval Required each and every risk"];
 
 

  Address1= {

    street: "",
    city: "",
    state:"",
    telephone: "",
    postalcode: "",
    website: ""
  }

  
  Address2={
    street: "Baker's Street",
    city: "London",
    state: "UK",
    telephone: "400 698",
    postalcode: "400 698",
    website: "www.willistowerswatson.com"
  }
  constructor() { }

  ngOnInit() {
  }
  copyAddress() {
    this.status=!this.status;
if(this.status==true){
  this.Address1 = this.Address2;
}
else{
  this.Address1={

    street: "",
    city: "",
    state:"",
    telephone: "",
    postalcode: "",
    website: ""
  };
}
    
  }
}
