import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-approval-status-change',
  templateUrl: './approval-status-change.component.html',
  styleUrls: ['./approval-status-change.component.css']
})
export class ApprovalStatusChangeComponent implements OnInit {
  approvalStatus =
  {
    companytype: "U.S. Life & Health",
    approvalstatus: "Pending"
  }
restrictions = ["Approved for US Healthcare business only",
  "Approved for US Related Business Only",
  "US Domestic Business only"];
qualifiers = ["Use Citizens Property Insurance Corporation Client Instruction Letter",
  "Use Risk Retention Group client instruction letter",
  "RPO Approval Required each and every risk"];
  constructor() { }

  ngOnInit() {
  }

}
