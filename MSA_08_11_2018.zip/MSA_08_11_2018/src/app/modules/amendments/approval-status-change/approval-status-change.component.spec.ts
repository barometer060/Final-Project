import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApprovalStatusChangeComponent } from './approval-status-change.component';

describe('ApprovalStatusChangeComponent', () => {
  let component: ApprovalStatusChangeComponent;
  let fixture: ComponentFixture<ApprovalStatusChangeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApprovalStatusChangeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApprovalStatusChangeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
