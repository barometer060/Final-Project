import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-approval',
  templateUrl: './new-approval.component.html',
  styleUrls: ['./new-approval.component.css']
})
export class NewApprovalComponent implements OnInit {
  restrictions = ["Approved for US Healthcare business only",
  "Approved for US Related Business Only",
  "US Domestic Business only"];
qualifiers = ["Use Citizens Property Insurance Corporation Client Instruction Letter",
  "Use Risk Retention Group client instruction letter",
  "RPO Approval Required each and every risk"];
  
newApproval={
  fetindicator:"Yes",
  lorscode:"12345",
  fein:"123",
  sanctionqual:"type1",
  approvalstatus:"Not Approved",
  addbranch:"No",
  fatscastatus:"Non Compliant: Confirmed",
  tobastatus:"Pending",
  ambestid:"1234567890",
  spid:"1234567890",
  moodysid:"1234567890",
  fitchid:"1234567890",
  carrieragency:"Yes"
}

  Address1= {

    street: "",
    city: "",
    state:"",
    telephone: "",
    postalcode: "",
    website: ""
  }

  address2={
    street: "Baker's Street",
    city: "London",
    state: "London",
    telephone: "907656354",
    postalcode: "405 678",
    website: "www.willistowerswatson.com"
  }
  constructor() { }

  ngOnInit() {
  }
  copyAddress() {

    this.Address1 = this.address2;

  }

}
