import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-no-longer-approved',
  templateUrl: './no-longer-approved.component.html',
  styleUrls: ['./no-longer-approved.component.css']
})
export class NoLongerApprovedComponent implements OnInit {

  restrictions = ["Approved for US Healthcare business only",
                  "Approved for US Related Business Only",
                  "US Domestic Business only"];
  qualifiers = ["Use Citizens Property Insurance Corporation Client Instruction Letter",
                "Use Risk Retention Group client instruction letter",
                "RPO Approval Required each and every risk"];
noLonger={
  companytype:"Non-Life Co",
  operatingcat:"Active",
  appstatus:"Not Approved",
  fatcastatus:"Non Compliant: Confirmed"
}
  constructor() { }

  ngOnInit() {
  }

}
