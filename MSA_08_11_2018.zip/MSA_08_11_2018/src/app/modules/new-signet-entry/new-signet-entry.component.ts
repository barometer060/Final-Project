import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute,Route } from '@angular/router';
declare var $: any;

@Component({
  selector: 'app-new-signet-entry',
  templateUrl: './new-signet-entry.component.html',
  styleUrls: ['./new-signet-entry.component.css']
})
export class NewSignetEntryComponent implements OnInit {
public id:any;
  constructor(private roter:Router,private route: ActivatedRoute) { }

  ngOnInit() {
    this.roter.navigate(['newrequest'])

this.id=this.route.snapshot.paramMap.get("id");
if(this.id==1)
  {
    this.loadExisting();
   // $('#existing').prop('checked', true); 
//document.getElementById("existing").setAttribute('checked',true);
  }
  // this.route.snapshot
  }
isNewEntry:boolean=false;
isExistingEntry:boolean=false;

  contentload(){
this.isNewEntry=true;
this.isExistingEntry=false;
this.roter.navigate(['newrequest/newsignetentryform'])

  }
loadExisting(){
this.isExistingEntry=true;
this.isNewEntry=false;
this.roter.navigate(['newrequest/namechange'])


}

}
