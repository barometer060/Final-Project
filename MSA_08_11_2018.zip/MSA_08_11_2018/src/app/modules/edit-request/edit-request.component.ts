import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-request',
  templateUrl: './edit-request.component.html',
  styleUrls: ['./edit-request.component.css']
})
export class EditRequestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
