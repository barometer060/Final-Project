import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';


import { AppComponent } from './app.component';
import { SearchComponent } from '../app/modules/search/search.component';
import { NameChangeComponent } from '../app/modules/amendments/name-change/name-change.component';
import { NewSignetEntryComponent } from '../app/modules/new-signet-entry/new-signet-entry.component';
import { AppRouting } from '../app/app.routing';
import { HeaderComponent } from '../app/shared/header/header.component';
import { FooterComponent } from '../app/shared/footer/footer.component';
import { DatepickerComponent } from '../app/user-controls/datepicker/datepicker.component';
import { NewSignetEntryFormComponent } from '../app/modules/new-signet-entry-form/new-signet-entry-form.component';
import { NewApprovalComponent } from '../app/modules/amendments/new-approval/new-approval.component';
import { NoLongerApprovedComponent } from '../app/modules/amendments/no-longer-approved/no-longer-approved.component';
import { ApprovalStatusChangeComponent } from '../app/modules/amendments/approval-status-change/approval-status-change.component';
import { UpdateToUnderlyingSecComponent } from '../app/modules/amendments/update-to-underlying-sec/update-to-underlying-sec.component';
import { EditRequestComponent } from '../app/modules/edit-request/edit-request.component';
import { TabsComponent } from '../app/modules/tabs/tabs.component';
import { AnalystComponent } from '../app/modules/roles/analyst/analyst.component';
import { ReviewerComponent } from '../app/modules/roles/reviewer/reviewer.component';
import { SpoeComponent } from '../app/modules/roles/spoe/spoe.component';
import { HistoricalDataComponent } from '../app/modules/historical-data/historical-data.component';
import { PaginationComponent } from '../app/user-controls/pagination/pagination.component';
import { SignetUpdatedByComponent } from './modules/roles/signet-updated-by/signet-updated-by.component';


@NgModule({
  declarations: [
    AppComponent,
    SearchComponent,
    NameChangeComponent,
    NewSignetEntryComponent,
    HeaderComponent,
    FooterComponent,
   DatepickerComponent,
   NewSignetEntryFormComponent,
   NewApprovalComponent,
   NoLongerApprovedComponent,
   ApprovalStatusChangeComponent,
   UpdateToUnderlyingSecComponent,
   EditRequestComponent,
   TabsComponent,
   AnalystComponent,
   ReviewerComponent,
   SpoeComponent,
   HistoricalDataComponent,
   PaginationComponent,
   SignetUpdatedByComponent
  ],
  imports: [
    BrowserModule,
    AppRouting,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
